# Creativity Project 2

We used JQuery and AJAX to create a dynamic mouse that displays a gif. 

We created a grid button system so that you can change the style of your mouse and it plays corresponding music too.
